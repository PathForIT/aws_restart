color={"balck" : "dog","Blue" : "sky","red" : "level"}
print(color)
print(type(color))
