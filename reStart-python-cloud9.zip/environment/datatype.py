Hello=2
print(Hello)
print(type(Hello))
id(Hello)