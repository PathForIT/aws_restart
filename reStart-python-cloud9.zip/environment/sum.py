a=10
b=30
print("The sum;",(a+b))